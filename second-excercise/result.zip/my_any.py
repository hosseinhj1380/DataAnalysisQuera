# coding: utf-8
def my_any(x):
    for xs in x :
        if xs :
            pass 
        else:
            return False
    return True
